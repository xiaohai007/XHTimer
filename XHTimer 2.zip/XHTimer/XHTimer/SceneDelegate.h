//
//  SceneDelegate.h
//  XHTimer
//
//  Created by yulong Yang on 2020/11/9.
//  Copyright © 2020 yulong Yang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

