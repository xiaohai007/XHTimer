//
//  ViewController.m
//  XHTimer
//
//  Created by yulong Yang on 2020/11/9.
//  Copyright © 2020 yulong Yang. All rights reserved.
//

#import "ViewController.h"
#import "XHTimerDispatchSource.h"
@interface ViewController ()
@property (nonatomic, strong) XHTimerDispatchSource *timer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [XHTimerDispatchSource sharedTimerManager].timeRange = 10;
    [XHTimerDispatchSource sharedTimerManager].TimeinCall = ^{
        NSLog(@"Hello World");
    };
    [XHTimerDispatchSource sharedTimerManager].TimeoutCall = ^(NSString *text) {
        NSLog(@"%@", text);
    };
    [[XHTimerDispatchSource sharedTimerManager] startTimer];
    
    // 恢复时间数据源按钮
    UIButton *btnResume = [[UIButton alloc] initWithFrame:CGRectMake(150, 150, 100, 40)];
    [btnResume setTitle:@"恢复" forState:UIControlStateNormal];
    [btnResume addTarget:self action:@selector(btnResumeClick:) forControlEvents:UIControlEventTouchUpInside];
    btnResume.backgroundColor = [UIColor blueColor];
    [self.view addSubview:btnResume];
    
    // 暂停时间数据源按钮
    UIButton *btnSuppend = [[UIButton alloc] initWithFrame:CGRectMake(150, 250, 100, 40)];
    btnSuppend.backgroundColor = [UIColor blueColor];
    [btnSuppend setTitle:@"暂停" forState:UIControlStateNormal];
    [btnSuppend addTarget:self action:@selector(suppendTimerClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnSuppend];
}

- (void)btnResumeClick:(UIButton *)sender {
    [[XHTimerDispatchSource sharedTimerManager] resumeTimer];
}

- (void)suppendTimerClick:(UIButton *)sender {
    [[XHTimerDispatchSource sharedTimerManager] pauseTimer];
}

- (void)dealloc {
    [[XHTimerDispatchSource sharedTimerManager] stopTimer];
    NSLog(@"销毁");
}
@end
